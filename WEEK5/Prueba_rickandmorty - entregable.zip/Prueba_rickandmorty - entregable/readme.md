**Prueba Técnica: Rick and Morty API + HubSpot**

 **Descripción**

Este proyecto consume la API pública de Rick and Morty, procesa y filtra personajes, transforma sus datos y sincroniza la información con los contactos de HubSpot mediante su API CRM.

El backend está desarrollado en Python con FastAPI.

**Tecnologías utilizadas**

- Python
- FastAPI
- HTTPX
- Requests
- API de Rick and Morty
- API CRM de HubSpot

**Funcionalidades**

- Consulta de personajes desde la API de Rick and Morty.
- Recorrido de las páginas disponibles de la API.
- Filtrado de personajes con 10 o más episodios.
- Transformación de datos para adaptarlos a las propiedades de contacto de HubSpot.
- Búsqueda de contactos existentes mediante el identificador **'rick_id'**.
- Prevención de duplicados antes de crear contactos.
- Creación de contactos que no existen en HubSpot.
- Manejo de respuestas HTTP y control de solicitudes para reducir errores por límites de uso.

 **Endpoints**


1. GET /

Comprueba que la API está funcionando correctamente.

2. GET /personajes

Obtiene los personajes de la API de Rick and Morty, filtra aquellos que tienen 10 o más episodios y transforma sus datos para prepararlos para HubSpot.

3. POST /enviar-hubspot

Busca los personajes en HubSpot para evitar duplicados y crea los contactos que todavía no existen. Devuelve el resultado del procesamiento de cada personaje.

**requisito**

- Python instalado.
- Una cuenta de HubSpot con acceso a la API CRM.
- Un token válido de una aplicación privada de HubSpot.
- Las propiedades personalizadas utilizadas por el proyecto, como*rick_id**creadas en HubSpot.

**Instalación**

1. Abre una terminal en la carpeta **'backend'**.
2. Instala las dependencias:

   ```powershell
   python -m pip install -r requirements.txt
   ```

3. Configura el token de HubSpot en la terminal de PowerShell:

   ```powershell
   $env: HUBSPOT_TOKEN=**TOKEN_DE_HUBSPOT**
   ```

   Sustituye el texto de ejemplo por tu token real. No lo publiques ni lo incluyas en el repositorio.

4. Inicia el servidor:

   ```powershell
   python -m uvicorn main:app --reload
   ```

**Pruebas**

La documentación interactiva está disponible en:

**'http://127.0.0.1:8000/docs'**

Desde allí se pueden ejecutar los endpoints y revisar las respuestas.

**Seguridad**

El token de HubSpot se obtiene mediante una variable de entorno y no debe escribirse directamente en el código fuente ni compartirse públicamente.

**Autor**

Proyecto desarrollado como parte de una prueba técnica de integración de APIs.
