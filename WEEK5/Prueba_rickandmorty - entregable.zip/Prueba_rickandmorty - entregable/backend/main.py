
# Importaciones
import os # Importamos os para leer variables de entorno del sistema operativo.
import time
import asyncio # Importamos FastAPI para crear nuestra API.
import requests # Importamos requests para consultar la API de Rick and Morty.
import httpx # Importamos httpx para realizar peticiones asíncronas a HubSpot.
from fastapi import FastAPI

# Permitimos una sola operación de búsqueda de HubSpot a la vez.
limite_concurrencia = asyncio.Semaphore(1)

# Creamos la aplicación FastAPI.
app = FastAPI()

# token de hgubspot
token_hubspot = os.getenv("HUBSPOT_TOKEN")
print("Token cargado en FastAPI:", bool(token_hubspot))

@app.get("/")
def inicio():
    # Comprueba que el backend está funcionando.
    return {"mensaje": "Funcionando correctamente"}


@app.get("/personajes")
def obtener_personajes():
    # Consultamos los personajes de Rick and Morty.
    url = "https://rickandmortyapi.com/api/character"
    personajes = []

    while url:
        try:
            respuesta = requests.get(url, timeout=20)
        except requests.RequestException as error:
            return {
                "error": "No se pudo conectar con Rick and Morty",
                "detalle": str(error)
            }

        # Si la API limita las peticiones, esperamos y reintentamos.
        if respuesta.status_code == 429:
            time.sleep(5)
            continue

        # Si hay otro error, lo informamos.
        if respuesta.status_code != 200:
            return {
                "error": "No se pudo consultar la API de Rick and Morty",
                "codigo": respuesta.status_code,
                "detalle": respuesta.text
            }

        datos = respuesta.json()

        # Guardamos los personajes de esta página.
        personajes.extend(datos["results"])

        # Obtenemos la siguiente página.
        url = datos["info"]["next"]

        # Reducimos la frecuencia de las consultas.
        if url:
            time.sleep(1)

    personajes_filtrados = []

    for personaje in personajes:
        cantidad_episodios = len(personaje["episode"])

        # Seleccionamos personajes que aparecen en 10 episodios o más.
        if cantidad_episodios >= 10:
            personaje_transformado = {
                "rick_id": personaje["id"],
                "firstname": personaje["name"],
                "rick_status": personaje["status"],
                "rick_species": personaje["species"],
                "rick_gender": personaje["gender"],
                "rick_episodes": cantidad_episodios,
                "rick_classification": "Principal"
            }

            personajes_filtrados.append(personaje_transformado)

    return {
        "total_personajes": len(personajes),
        "total_filtrados": len(personajes_filtrados),
        "personajes": personajes_filtrados
    }


async def buscar_por_rick_id(rick_id):
    # Buscamos un contacto usando el ID de Rick and Morty.
    url = "https://api.hubapi.com/crm/v3/objects/contacts/search"

    headers = {
        "Authorization": f"Bearer {token_hubspot}",
        "Content-Type": "application/json"
    }

    datos = {
        "filterGroups": [
            {
                "filters": [
                    {
                        "propertyName": "rick_id",
                        "operator": "EQ",
                        "value": str(rick_id)
                    }
                ]
            }
        ],
        "properties": ["rick_id", "firstname"],
        "limit": 1
    }

    # Evitamos que las búsquedas se acumulen y excedan el límite.
    async with limite_concurrencia:
        async with httpx.AsyncClient(timeout=30) as cliente:
            for intento in range(3):
                respuesta = await cliente.post(
                    url,
                    headers=headers,
                    json=datos
                )

                # Si no es un error 429, devolvemos la respuesta.
                if respuesta.status_code != 429:
                    return respuesta

                # Esperamos progresivamente antes de reintentar.
                if intento < 2:
                    await asyncio.sleep(10 * (intento + 1))

            # Si agotamos los intentos, devolvemos el último error.
            return respuesta


async def enviar_a_hubspot(personaje):
    # Creamos un contacto con los datos transformados.
    url = "https://api.hubapi.com/crm/v3/objects/contacts"

    headers = {
        "Authorization": f"Bearer {token_hubspot}",
        "Content-Type": "application/json"
    }

    datos = {
        "properties": {
            "rick_id": str(personaje["rick_id"]),
            "firstname": personaje["firstname"],
            "rick_status": personaje["rick_status"],
            "rick_species": personaje["rick_species"],
            "rick_gender": personaje["rick_gender"],
            "rick_episodes": str(personaje["rick_episodes"]),
            "rick_classification": personaje["rick_classification"]
        }
    }

    async with httpx.AsyncClient(timeout=30) as cliente:
        respuesta = await cliente.post(
            url,
            headers=headers,
            json=datos
        )

    return respuesta


async def procesar_personaje(personaje):
    # Primero verificamos si el contacto ya existe.
    try:
        busqueda = await buscar_por_rick_id(personaje["rick_id"])
    except httpx.RequestError as error:
        return {
            "personaje": personaje["firstname"],
            "estado": "error de conexión al buscar",
            "detalle": str(error)
        }

    # Si HubSpot responde con error, mostramos el detalle.
    if busqueda.status_code != 200:
        return {
            "personaje": personaje["firstname"],
            "estado": "error al buscar",
            "codigo": busqueda.status_code,
            "detalle": busqueda.text,
            "espera_recomendada": busqueda.headers.get("Retry-After")
        }

    datos_busqueda = busqueda.json()

    # Si ya existe, no lo creamos de nuevo.
    if datos_busqueda.get("results"):
        return {
            "personaje": personaje["firstname"],
            "estado": "ya existe",
            "codigo": 200
        }

    # Si no existe, intentamos crearlo.
    try:
        respuesta = await enviar_a_hubspot(personaje)
    except httpx.RequestError as error:
        return {
            "personaje": personaje["firstname"],
            "estado": "error de conexión al crear",
            "detalle": str(error)
        }

    if respuesta.status_code == 201:
        return {
            "personaje": personaje["firstname"],
            "estado": "creado",
            "codigo": respuesta.status_code
        }

    return {
        "personaje": personaje["firstname"],
        "estado": "error al crear",
        "codigo": respuesta.status_code,
        "detalle": respuesta.text
    }


@app.post("/enviar-hubspot")
async def sincronizar_personajes():
    # Obtenemos los personajes transformados.
    resultado = obtener_personajes()

    # Si la API de origen falló, devolvemos su error.
    if "error" in resultado:
        return resultado

    personajes = resultado["personajes"]

    # Creamos una tarea por personaje.
    tareas = [
        procesar_personaje(personaje)
        for personaje in personajes
    ]

    # Ejecutamos las tareas; las búsquedas se limitan con el semáforo.
    resultados = await asyncio.gather(*tareas)

    return {
        "total_personajes": len(personajes),
        "resultados": resultados
    }
